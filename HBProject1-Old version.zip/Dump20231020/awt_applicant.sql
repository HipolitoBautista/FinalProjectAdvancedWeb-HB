CREATE DATABASE  IF NOT EXISTS `awt` /*!40100 DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci */ /*!80016 DEFAULT ENCRYPTION='N' */;
USE `awt`;
-- MySQL dump 10.13  Distrib 8.0.34, for Linux (x86_64)
--
-- Host: localhost    Database: awt
-- ------------------------------------------------------
-- Server version	8.0.34

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `applicant`
--

DROP TABLE IF EXISTS `applicant`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `applicant` (
  `id` int NOT NULL,
  `first_name` varchar(255) DEFAULT NULL,
  `last_name` varchar(255) DEFAULT NULL,
  `username` varchar(255) DEFAULT NULL,
  `password` varchar(255) DEFAULT NULL,
  `country` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `applicant`
--

LOCK TABLES `applicant` WRITE;
/*!40000 ALTER TABLE `applicant` DISABLE KEYS */;
INSERT INTO `applicant` VALUES (1,'Corbett','Davidai','cdavidai0','$2a$04$A/vkJacMis.lyT9C5ZdzguBZBhyU4Qh2YNh9/KDKkaS2lrxxozkfS','China'),(2,'Fitzgerald','Grimbaldeston','fgrimbaldeston1','$2a$04$izP9dHFLxqrFD3FysGsIeOnx9uMDzmP0oiRr9yBTj18dlAUcRm18e','China'),(3,'Betsey','Davie','bdavie2','$2a$04$qXz5TbzXkiJY2kqe2MMMbO4Q6md87N5FMN7ZJ7oPqu3hIHAnofNEW','China'),(4,'Lorine','Rubinchik','lrubinchik3','$2a$04$QlgACO5kDEZZk.E4YuZSR.cLaWPEKLAcGInLgmt3vZLfJmdnDFtD2','Russia'),(5,'Ronnica','Free','rfree4','$2a$04$yzKU7wF.T7bFBdnCpaIVDuFBtwBXTs4zlT8hVMIit6EWK9WJ4pDx2','Philippines'),(6,'Jaquelyn','Crighton','jcrighton5','$2a$04$WETBaFDXTlMO6GgJIBMKNOTNDLoFyMbGjd0GPKCh.tPPAgX64IYAa','China'),(7,'Antonio','Vezey','avezey6','$2a$04$1N69yd68UOJgVmzvgXAMHuJ2IdJUkjk.CjxMZjwRrP6lkFYFww3bK','Philippines'),(8,'Johan','McElhargy','jmcelhargy7','$2a$04$ehLEBAllWbwFX1Edw4VD/OR0Yyqoa5paTzwebDsCU3oI3zeHMOjjK','Peru'),(9,'Mil','Bramford','mbramford8','$2a$04$iP5Tly1tbOql6xcQ2aQw0O/Rlye1yWayLcd1uuc6umdLVRlO9qD4y','Russia'),(10,'Toddie','Joinson','tjoinson9','$2a$04$eHhFseP112pHOOzDNvDr..7PaOcb7CVljExnzfOJ71dQI/eXaoYI.','Norway'),(13,'John','Doe','johndoeee123','$2y$10$QV9vvxrD5EsVNAR3k81BOe3slWPvQbMSAPicFWMLKF.j6a2hXPFOm','USA');
/*!40000 ALTER TABLE `applicant` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2023-10-20 19:11:22
